package com.vizor.optirec;

import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_458;
import net.minecraft.class_4587;

public class RecSettingsScreen extends class_437 {

    private static String statusMsg = "";
    private static long statusUntil = 0;

    public RecSettingsScreen() {
        super(new class_2585("Настройки OptiRec"));
    }

    public static void toast(String msg, long ms) {
        statusMsg = msg;
        statusUntil = System.currentTimeMillis() + ms;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int y = 40;

        this.method_25411(new class_4185(cx - 140, y, 280, 22,
                new class_2585(Recorder.isRecording()
                        ? "§c■ ОСТАНОВИТЬ ЗАПИСЬ"
                        : "§a● НАЧАТЬ ЗАПИСЬ ЭКРАНА"),
                b -> {
                    toggleRecording();
                    this.method_25423(this.field_22787, this.field_22789, this.field_22790);
                }));
        y += 28;

        this.method_25411(new class_4185(cx - 140, y, 280, 20,
                new class_2585("§eНазначить клавиши (Управление)"),
                b -> class_310.method_1551().method_1507(
                        new class_458(this, class_310.method_1551().field_1690))));
        y += 26;

        this.method_25411(new class_4185(cx - 140, y, 280, 20,
                new class_2585(String.format("§7Разрешение: %dx%d", getRecWidth(), getRecHeight())),
                b -> {}));
        y += 26;

        this.method_25411(new class_4185(cx - 140, y, 280, 20,
                new class_2585("§7FFmpeg: " + (Recorder.findFfmpegReport() ? "§aнайден" : "§cНЕ найден!")),
                b -> {}));
        y += 30;

        this.method_25411(new class_4185(cx - 140, y, 280, 20,
                new class_2585("Готово"), b -> this.method_25419()));
    }

    private void toggleRecording() {
        if (Recorder.isRecording()) {
            Recorder.stop();
            toast("§cЗапись остановлена → .minecraft/recordings/", 4000);
        } else {
            int w = getRecWidth();
            int h = getRecHeight();
            if (Recorder.start(w, h)) {
                toast("§a● Идёт запись... Стоп — клавиша (по умолч. F8)", 3500);
            } else {
                toast("§4Ошибка: не найден FFmpeg", 4000);
            }
        }
    }

    private static int getRecWidth() {
        class_310 mc = class_310.method_1551();
        return mc.method_22683() != null ? mc.method_22683().method_4489() : 1280;
    }

    private static int getRecHeight() {
        class_310 mc = class_310.method_1551();
        return mc.method_22683() != null ? mc.method_22683().method_4506() : 720;
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25420(matrices);
        net.minecraft.class_332.method_25300(matrices, this.field_22793,
                "§6§lOptiRec §7— §fзапись полного экрана (GUI+чат)", this.field_22789 / 2, 12, 0xFFFFFF);
        drawCenteredText(matrices, "Файл → .minecraft/recordings/rec_....mp4 (FFmpeg, 30 FPS)", 34, 0xAAAAAA);
        drawCenteredText(matrices, "F8 — старт/стоп записи, F9 — это меню", 48, 0xAAAAAA);

        if (System.currentTimeMillis() < statusUntil && !statusMsg.isEmpty()) {
            drawCenteredText(matrices, statusMsg, 62, 0xFFFFFF);
        }
        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    private void drawCenteredText(class_4587 matrices, String text, int y, int color) {
        this.field_22793.method_1720(matrices, text,
                (this.field_22789 - this.field_22793.method_1727(text)) / 2f, y, color);
    }
}
