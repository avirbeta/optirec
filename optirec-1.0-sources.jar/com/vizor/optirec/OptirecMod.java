package com.vizor.optirec;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2585;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class OptirecMod implements ClientModInitializer {

    private static class_304 toggleRec;
    private static class_304 openSettings;
    private static int lastRecWidth = -1;
    private static int lastRecHeight = -1;

    @Override
    public void onInitializeClient() {
        toggleRec = KeyBindingHelper.registerKeyBinding(new class_304(
                "Старт/Стоп записи экрана",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F8,
                "OptiRec"
        ));
        openSettings = KeyBindingHelper.registerKeyBinding(new class_304(
                "Открыть меню OptiRec",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F9,
                "OptiRec"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleRec.method_1436()) {
                toggleRecording(client);
            }
            while (openSettings.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new RecSettingsScreen());
                }
            }
        });

        HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            if (Recorder.isRecording()) {
                drawIndicator(matrices);
            }
        });
    }

    private static void toggleRecording(class_310 mc) {
        if (Recorder.isRecording()) {
            Recorder.stop();
            RecSettingsScreen.toast("§cЗапись остановлена → .minecraft/recordings/", 4000);
            sendChat(mc, "§c[OptiRec] Запись остановлена → .minecraft/recordings/");
        } else {
            int w = mc.method_22683() != null ? mc.method_22683().method_4489() : 1280;
            int h = mc.method_22683() != null ? mc.method_22683().method_4506() : 720;
            lastRecWidth = w;
            lastRecHeight = h;
            if (Recorder.start(w, h)) {
                RecSettingsScreen.toast("§a● Идёт запись... (стоп — F8)", 3500);
                sendChat(mc, "§a[OptiRec] ● Идёт запись экрана... (стоп — F8)");
            } else {
                RecSettingsScreen.toast("§4Ошибка: не найден FFmpeg", 4000);
                sendChat(mc, "§4[OptiRec] Ошибка: не найден FFmpeg");
            }
        }
    }

    private static void sendChat(class_310 mc, String text) {
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(new class_2585(text), false);
        }
    }

    private static void drawIndicator(net.minecraft.class_4587 matrices) {
        class_310 mc = class_310.method_1551();
        long secs = Recorder.getElapsedMs() / 1000;
        String time = String.format("%02d:%02d", secs / 60, secs % 60);
        String text = "§c● REC " + time;
        // красный полупрозрачный фон + текст вправо
        int w = mc.field_1772.method_1727(text) + 8;
        net.minecraft.class_332.method_25294(matrices, mc.method_22683().method_4486() - w - 4, 4,
                mc.method_22683().method_4486() - 4, 18, 0x88000000);
        mc.field_1772.method_1720(matrices, text,
                mc.method_22683().method_4486() - w, 7, 0xFFFFFF);
    }
}
